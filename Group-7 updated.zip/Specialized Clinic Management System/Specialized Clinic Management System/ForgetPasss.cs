﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Reflection.Emit;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Specialized_Clinic_Management_System
{
    public partial class ForgetPasss : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\NAZMUS SAKIB\OneDrive\Documents\CMSdb.mdf"";Integrated Security=True;Connect Timeout=30");
        public ForgetPasss()
        {
            InitializeComponent();
        }
        void populate()
        {
            Con.Open();
            string query = "select * from ForgetPass";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            ForgetGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (newpassword.Text == "" || rewritepassword.Text == "")
                MessageBox.Show("No Empty Fill Accepted");
            else
            {
                Con.Open();
                string query = "Insert into ForgetPass values(" + newpassword.Text + ",'" + rewritepassword.Text + "')";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("PassWord Change Successfully");
                Con.Close();
                populate();
            }
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void ForgetPasss_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void ForgetGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            newpassword.Text = ForgetGV.SelectedRows[0].Cells[0].Value.ToString();
           rewritepassword.Text = ForgetGV.SelectedRows[0].Cells[1].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == rewritepassword.Text)
            {
                label4.Visible = true;
                label5.Visible = false;
            }
            else
            {
                label4.Visible = false;
                label5.Visible = true;
            }
        }

        private void newpassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void rewritepassword_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
