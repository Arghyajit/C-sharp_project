﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Runtime.Remoting.Contexts;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Reflection.Emit;

namespace Specialized_Clinic_Management_System
{
    public partial class Form1 : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\NAZMUS SAKIB\OneDrive\Documents\CMSdb.mdf"";Integrated Security=True;Connect Timeout=30");
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (DocNameTb.Text == "" || PassTb.Text == "")
                MessageBox.Show("Enter Username And Password");
            else
            {
                Con.Open();
                SqlCommand cmd= new SqlCommand("select * from Login where username='"+DocNameTb.Text+"' and password='"+PassTb.Text+"'", Con);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt= new DataTable();
                sda.Fill(dt);
                string cmbItemValue = comboBox1.SelectedItem.ToString();
                if (dt.Rows.Count > 0)
                {
                    for(int i = 0; i < dt.Rows.Count; i++) 
                    { 
                        if (dt.Rows[i]["usertype"].ToString() == cmbItemValue) 
                        {
                            MessageBox.Show("You are login as " + dt.Rows[i][2]);
                            if (comboBox1.SelectedIndex == 0) 
                            {
                                Home H = new Home();
                                H.Show();
                                this.Hide();
                            }
                            else
                            {
                                PatientFrom patient= new PatientFrom();
                                patient.Show();
                                this.Hide();
                            }
                        }
                    }
                    
                }
                else 
                {
                    MessageBox.Show("Wrong UserName or Password");
                }
                Con.Close();
            }
           
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit ();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DocNameTb.Text = "";
            PassTb.Text = "";
            DocNameTb.Focus();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Registration reg = new Registration();
            reg.Show();
            this.Hide();
        }

        private void DocNameTb_TextChanged(object sender, EventArgs e)
        {
            string email = DocNameTb.Text;
            if (email.Contains("@") & email.Contains(".com"))
            {
                label5.Visible = true;
                label6.Visible = false;
            }
            else
            {
                label5.Visible = false;
                label6.Visible = true;
            }
        }

        private void PassTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            ForgetPasss fp = new ForgetPasss();
            fp.Show();
            this.Hide();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                PassTb.UseSystemPasswordChar = true;
            }
            else
            {
                PassTb.UseSystemPasswordChar = false;
            }
        }
    }
}
