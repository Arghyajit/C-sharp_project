﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Specialized_Clinic_Management_System
{
    public partial class PatientFrom : Form
    {
        public PatientFrom()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\NAZMUS SAKIB\OneDrive\Documents\CMSdb.mdf"";Integrated Security=True;Connect Timeout=30");
        void populate()
        {
            Con.Open();
            string query = "select * from PatientTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            PatientGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 h = new Form1();
            h.Show();
            this.Hide();
        }

        private void DoctorGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            PatId.Text = PatientGV.SelectedRows[0].Cells[0].Value.ToString();
            PatName.Text = PatientGV.SelectedRows[0].Cells[1].Value.ToString();
            PatAd.Text = PatientGV.SelectedRows[0].Cells[2].Value.ToString();
            PatPhone.Text = PatientGV.SelectedRows[0].Cells[3].Value.ToString();
            PatAge.Text = PatientGV.SelectedRows[0].Cells[4].Value.ToString();
            MajorTb.Text = PatientGV.SelectedRows[0].Cells[5].Value.ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (PatId.Text == "" || PatName.Text == "" ||PatAd.Text == "" || PatPhone.Text == ""|| PatAge.Text == ""||MajorTb.Text == "")
                MessageBox.Show("No Empty Fill Accepted");
            else
            {
                Con.Open();
                string query = "Insert into PatientTbl values(" + PatId.Text + ",'" + PatName.Text + "','" + PatAd.Text + "','" + PatPhone.Text + "','"+PatAge.Text+"','"+GenderCb.SelectedItem.ToString()+"','"+BloodCb.SelectedItem.ToString()+"','"+MajorTb.Text+"')";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Patient Added Successfully");
                Con.Close();
                populate();
            }
        }

        private void PatientFrom_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (PatId.Text == "")
                MessageBox.Show("Enter The Patient Id");
            else
            {
                Con.Open();
                string query = "delete from PatientTbl where PatId=" + PatId.Text + "";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Patient deleted Successfully ");
                Con.Close();
                populate();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (PatId.Text == "" || PatName.Text == "" || PatAd.Text == "" || PatPhone.Text == "" || PatAge.Text == "" || MajorTb.Text == "")
                MessageBox.Show("No Empty Fill Accepted");
            else
            {
                Con.Open();
                string query = "update PatientTbl set PatName = '" + PatName.Text + "',PatAddress ='" + PatAd.Text + "',PatPhone='" + PatPhone.Text + "',PatAge='" + PatAge.Text + "',PatGender='" + GenderCb.SelectedItem.ToString() + "',PatBlood='" + BloodCb.SelectedItem.ToString() + "' where PatId=" + PatId.Text + "";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Patient Updated Successfully");
                Con.Close();
                populate();
            }
        }

        private void PatientGV_DoubleClick(object sender, EventArgs e)
        {
            PatId.Text = PatientGV.SelectedRows[0].Cells[0].Value.ToString();
            PatName.Text = PatientGV.SelectedRows[0].Cells[1].Value.ToString();
            PatAd.Text = PatientGV.SelectedRows[0].Cells[2].Value.ToString();
            PatPhone.Text = PatientGV.SelectedRows[0].Cells[3].Value.ToString();
            PatAge.Text = PatientGV.SelectedRows[0].Cells[4].Value.ToString();
            PatAge.Text = PatientGV.SelectedRows[0].Cells[4].Value.ToString();
            GenderCb.Text= PatientGV.SelectedRows[0].Cells[5].Value.ToString();
            BloodCb.Text = PatientGV.SelectedRows[0].Cells[6].Value.ToString();
            MajorTb.Text = PatientGV.SelectedRows[0].Cells[7].Value.ToString();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            PatId.Clear();
            PatName.Clear(); PatAd.Clear(); PatPhone.Clear(); PatAge.Clear(); 
            GenderCb.Items.Clear();BloodCb.Items.Clear();MajorTb.Clear
                ();
            PatId.Focus();
        }

        private void PatPhone_TextChanged(object sender, EventArgs e)
        {
            string number = PatPhone.Text;
            if((number.Length == 11)&&(number.StartsWith  ("01"))) 
            {
                label12.Visible = true; 
                label13.Visible = false;
            }
            else
            {
                label12.Visible=false;
                label13.Visible=true;
            }
        }
    }
}
