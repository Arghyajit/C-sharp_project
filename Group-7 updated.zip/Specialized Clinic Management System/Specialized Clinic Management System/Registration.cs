﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;

namespace Specialized_Clinic_Management_System
{
    public partial class Registration : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\NAZMUS SAKIB\OneDrive\Documents\CMSdb.mdf"";Integrated Security=True;Connect Timeout=30");

        public Registration()
        {
            InitializeComponent();
        }
        void populate()
        {
            Con.Open();
            string query = "select * from RegistrationTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            RegGV.DataSource = ds.Tables[0];
            Con.Close();
        }


        private void Registration_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
        private void button2_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == ""|| textBox7.Text == "" ||   textBox8.Text == "")
                MessageBox.Show("No Empty Fill Accepted");
            else
            {
                Con.Open();
                string query = "Insert into RegistrationTbl values(" + textBox1.Text + ",'" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox7.Text + "','" + radioButton1.Checked + "','" + radioButton2.Checked + "','" + dateTimePicker1.Checked + "','" + comboBox1.SelectedItem.ToString() + "','" + textBox8.Text + "')";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("User Added Successfully");
                Con.Close();
                populate();
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if(textBox4.Text == textBox5.Text)
            {
                label13.Visible = true;
                label14.Visible = false;
            }
            else
            {
                label13.Visible = false;
                label14.Visible = true;
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            string number = textBox6.Text;
            if((number.Length == 11) && (number.StartsWith("01")))
            {
                label15.Visible = true;
                label16.Visible = false;
            }
            else
            {
                label15.Visible = false;
                label16.Visible = true;
            }
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            string email = textBox7.Text;
            if(email.Contains("@")& email.Contains(".com"))
            {
                label17.Visible = true;
                label18.Visible = false;
            }
            else
            {
                label17.Visible = false;
                label18.Visible = true;
            }
        }

        private void RegGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = RegGV.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = RegGV.SelectedRows[0].Cells[1].Value.ToString();
            textBox3.Text = RegGV.SelectedRows[0].Cells[2].Value.ToString();
            textBox4.Text = RegGV.SelectedRows[0].Cells[3].Value.ToString();
            textBox5.Text = RegGV.SelectedRows[0].Cells[4].Value.ToString();
            textBox6.Text = RegGV.SelectedRows[0].Cells[4].Value.ToString();
            textBox7.Text = RegGV.SelectedRows[0].Cells[5].Value.ToString();
            radioButton1.Text = RegGV.SelectedRows[0].Cells[6].Value.ToString();
            radioButton2.Text = RegGV.SelectedRows[0].Cells[7].Value.ToString();
            comboBox1.Text = RegGV.SelectedRows[0].Cells[9].Value.ToString();
            dateTimePicker1.Text = RegGV.SelectedRows[0].Cells[8].Value.ToString();

        }
    }
}
