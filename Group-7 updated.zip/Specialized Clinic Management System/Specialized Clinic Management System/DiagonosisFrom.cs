﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.SqlClient;
using System.Xml.XPath;

namespace Specialized_Clinic_Management_System
{
    public partial class DiagonosisFrom : Form
    {
        public DiagonosisFrom()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\NAZMUS SAKIB\OneDrive\Documents\CMSdb.mdf"";Integrated Security=True;Connect Timeout=30");
        void populaecombo() 
        {
            string sql = "select * from PatientTbl";
            SqlCommand cmd = new SqlCommand(sql, Con);
            SqlDataReader rdr;
            try
            {
                Con.Open();
                DataTable dt = new DataTable();
                dt.Columns.Add("PatId",typeof(int));
                rdr = cmd.ExecuteReader();
                dt.Load(rdr);
                PatientIdCb.ValueMember = "PatId";
                PatientIdCb.DataSource= dt;
                Con.Close();
            }
            catch 
            {
                
            }
        }
        string patname;
        void fecthpatientname()
        {
            Con.Open();
            string mysql = "select * from PatientTbl where PatId=" + PatientIdCb.SelectedValue.ToString() + "";
            SqlCommand cmd =  new SqlCommand(mysql, Con);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            
            foreach (DataRow dr in dt.Rows) 
            {
                patname = dr["PatName"].ToString();
                PatientTb.Text = patname; 
            }
            Con.Close();

        }
        void populate()
        {
            Con.Open();
            string query = "select * from DiagnosisTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            DiagnosisGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Home h = new Home();
            h.Show();
            this.Hide();
        }
        private void button1_Click(object sender, EventArgs e)
        {

            if (DiagId.Text == "" ||MedicineTb.Text == "" || DiagnosisTb.Text == "" ||PatientTb.Text == "" || MedicineTb.Text == "" )
                MessageBox.Show("No Empty Fill Accepted");
            else
            {
                Con.Open();
                string query = "Insert into DiagnosisTbl values(" + DiagId.Text + "," + PatientIdCb.SelectedValue.ToString() + ",'" + PatientTb.Text + "','" + SymtomsTb.Text + "','" + DiagnosisTb.Text + "','" +MedicineTb.Text + "')";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Diagnosis Patient Added Successfully");
                Con.Close();
                populate();
            }
        }

        private void DiagonosisFrom_Load(object sender, EventArgs e)
        {
            populaecombo();
            populate();
        }

        private void PatientIdCb_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void PatientIdCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fecthpatientname();
        }

        private void DiagnosisGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DiagId.Text = DiagnosisGV.SelectedRows[0].Cells[0].Value.ToString();
            PatientIdCb.SelectedValue = DiagnosisGV.SelectedRows[0].Cells[1].Value.ToString();
            PatientTb.Text = DiagnosisGV.SelectedRows[0].Cells[2].Value.ToString();
            SymtomsTb.Text = DiagnosisGV.SelectedRows[0].Cells[3].Value.ToString();
            DiagnosisTb.Text = DiagnosisGV.SelectedRows[0].Cells[4].Value.ToString();
            MedicineTb.Text = DiagnosisGV.SelectedRows[0].Cells[5].Value.ToString();
            PatientNamelbl.Text = DiagnosisGV.SelectedRows[0].Cells[2].Value.ToString();
            Symptomslbl.Text = DiagnosisGV.SelectedRows[0].Cells[3].Value.ToString();
            Diagnosislbl.Text = DiagnosisGV.SelectedRows[0].Cells[4].Value.ToString();
            Medicineslbl.Text = DiagnosisGV.SelectedRows[0].Cells[5].Value.ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (DiagId.Text == "")
                MessageBox.Show("Enter The Diagnosis Id");
            else
            {
                Con.Open();
                string query = "delete from DiagnosisTbl where DiagId=" + DiagId.Text + "";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Diagnosis deleted Successfully ");
                Con.Close();
                populate();
            }
        }

        private void DiagnosisGV_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
         
        }

        private void DiagnosisGV_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            DiagId.Text = DiagnosisGV.SelectedRows[0].Cells[0].Value.ToString();
            PatientIdCb.SelectedValue = DiagnosisGV.SelectedRows[0].Cells[1].Value.ToString();
            PatientTb.Text = DiagnosisGV.SelectedRows[0].Cells[2].Value.ToString();
            SymtomsTb.Text = DiagnosisGV.SelectedRows[0].Cells[3].Value.ToString();
            DiagnosisTb.Text = DiagnosisGV.SelectedRows[0].Cells[4].Value.ToString();
            MedicineTb.Text = DiagnosisGV.SelectedRows[0].Cells[5].Value.ToString();
            PatientNamelbl.Text = DiagnosisGV.SelectedRows[0].Cells[2].Value.ToString();
            Symptomslbl.Text = DiagnosisGV.SelectedRows[0].Cells[3].Value.ToString();
            Diagnosislbl.Text = DiagnosisGV.SelectedRows[0].Cells[4].Value.ToString();
            Medicineslbl.Text = DiagnosisGV.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (DiagId.Text == "" || MedicineTb.Text == "" || DiagnosisTb.Text == "" || PatientTb.Text == "" || MedicineTb.Text == "")
                MessageBox.Show("No Empty Fill Accepted");
            else
            {
                Con.Open();
                string query = "update DiagnosisTbl set PatId = '" + PatientIdCb.SelectedValue.ToString() + "',PatName ='" + PatientTb.Text + "',Syntomps='" + SymtomsTb.Text + "',Diagnosis='" + DiagnosisTb.Text + "',Medicines='" + MedicineTb.Text + "'  where DiagId=" + DiagId.Text + "";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Diagnosis Patient Updated Successfully");
                Con.Close();
                populate();
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
           
        }
        Bitmap bmp;
        private void button5_Click(object sender, EventArgs e)
        {
            if (printPreviewDialog1.ShowDialog()==DialogResult.OK) 
            {
                printDocument1.Print();
            }
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void printDocument2_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

        }

        private void printDocument1_PrintPage_1(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString(label11.Text + "\n\n\n\n\n\n\n\n\n\n", new Font("Century Gothic", 25, FontStyle.Bold), Brushes.Green, new Point(230));
            e.Graphics.DrawString(PatientNamelbl.Text + "\n" + Symptomslbl.Text + "\n" + Diagnosislbl.Text + "\n" + Medicineslbl.Text, new Font("Century Gothic", 20, FontStyle.Bold), Brushes.Black, new Point(130, 150));
            e.Graphics.DrawString(label16.Text+"", new Font("Century Gothic", 20, FontStyle.Bold), Brushes.Red, new Point(230, 500));
        
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            DiagId.Clear();
            PatientTb.Clear();
            SymtomsTb.Clear();
            DiagnosisTb.Clear();
            MedicineTb.Clear();
            DiagId.Focus();
        }
    }
}
